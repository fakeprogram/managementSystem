<script setup>
// import { onMounted, ref } from 'vue';

// let users, names
// users = getData()
// names = ref(users)
// console.log(1)
// onMounted(async () => {
//     console.log(2)
// })
// console.log(3)

// function getData() {
//     let uData = [
//         { name: 'anadaf' },
//         { name: 'sefessf' },
//         { name: 'sefessf' },
//         { name: 'asdsaessf' },
//         { name: 'sefasfessf' },
//         { name: 'afasdessf' },
//         { name: 'sefessfs' },
//         { name: 'sedgbbbsf' },
//         { name: 'sedgbbbsf' },
//         { name: 'sedgbbbsf' },
//         { name: 'sedgbbbsf' },
//         { name: 'sedgbbbsf' },
//         { name: 'sedgbbbsf' },
//     ]
//     return uData
// }

</script>

<template>
    <!-- <div class="rightcontainer" id="rightBox"> -->
        <!-- <div class="users-box"> -->
            <!-- <div class="user-container" v-for="name in names"> -->
                <!-- <div class="head-img"></div> -->
                <!-- {{ name.name }} -->
            <!-- </div> -->
        <!-- </div> -->
        <!-- <div class="test"> -->
        <!-- </div> -->
    <!-- </div> -->

</template>

<style>
/* .rightcontainer { */
    /* position: absolute; */
    /* display: block; */
    /* height: 90%; */
    /* width: 20%; */
    /* right: 0; */
    /* top: 10%; */
    /* border: 1px solid white; */
    /* box-sizing: border-box; */
    /* z-index: 5; */
/* } */

/* .test { */
    /* display: block; */
    /* height: 40%; */
    /* width: 100%; */
    /* right: 0; */
    /* top: 0; */
    /* box-sizing: border-box; */
    /* z-index: 5; */
/* } */

/* .users-box {
    position: relative;
    margin-top: 5px;
    padding-left: 5px;
    padding-right: 5px;
    height: 60%;
    list-style: none;
    overflow: auto;
    -ms-overflow-style: none;
    display: block;
    border-bottom: 1px solid white;
} */

/* .users-box::-webkit-scrollbar {
    display: none;
}

.user-container {
    position: relative;
    margin-bottom: 3px;
    background-color: rgba(49, 49, 61, 0.5);
    height: 55px;
    list-style-type: none;
    border-radius: 6px;
    display: block;
    color: white;
    text-align:left;
    line-height: 55px;
    padding-left: 60px;
    box-sizing: border-box;
}

.user-container:hover {
    background-color: rgb(163, 167, 171);
}

.head-img {
    position:absolute;
    top: 10%;
    left: 0;
    display:block;
    height: 80%;
    width: 15%;
    background-image: url('/public/header_bg1.png');
    background-size:contain;
    box-sizing: content-box;
} */
</style>