<script setup>
// import baiDuMap from './components/baiDuMap.vue';
import topBox from './components/topBox.vue';
// import rightBox from './components/rightBox.vue'
</script>

<template>
  <router-view :key="$route.fullPath"></router-view>
</template>

<style scoped></style>

